package co.TashaBrianRusty.PlayTheWorld;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlayTheWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlayTheWorldApplication.class, args);
	}

}
