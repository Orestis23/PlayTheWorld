package co.TashaBrianRusty.PlayTheWorld;

import org.springframework.stereotype.Component;

@Component
public class AmadeusService {
	
	
	
	
	

}
