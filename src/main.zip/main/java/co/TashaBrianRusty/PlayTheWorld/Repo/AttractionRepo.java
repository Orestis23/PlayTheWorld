package co.TashaBrianRusty.PlayTheWorld.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import co.TashaBrianRusty.PlayTheWorld.entity.Attraction;

public interface AttractionRepo extends JpaRepository<Attraction, Integer>{

}
